import base64

with open("test3.jpg", "rb") as image_file:
    image_data = image_file.read()
    image_base64 = base64.b64encode(image_data).decode("utf-8")

f=open('log.txt','w')
f.write(image_base64)
f.close()
